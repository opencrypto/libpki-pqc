#! /bin/sh

./util/mktar.sh --name=_srcdist
